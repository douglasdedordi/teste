print("Ola")
